package apps.abhibhardwaj.com.doctriod.patient.appointments;

public class TimeSlot {

  private Long slot;

  public TimeSlot() {
  }

  public Long getSlot() {
    return slot;
  }

  public void setSlot(Long slot) {
    this.slot = slot;
  }
}
