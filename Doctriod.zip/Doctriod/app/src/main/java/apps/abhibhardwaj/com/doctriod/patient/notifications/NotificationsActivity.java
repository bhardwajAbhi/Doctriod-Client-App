package apps.abhibhardwaj.com.doctriod.patient.notifications;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import apps.abhibhardwaj.com.doctriod.patient.R;

public class NotificationsActivity extends AppCompatActivity {

  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_notifications);
  }
}
