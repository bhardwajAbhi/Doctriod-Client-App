package apps.abhibhardwaj.com.doctriod.patient.appointments;

import android.view.View;

public interface RecyclerItemSelectedListener {

  void onItemSelectedListener(View view, int position);


}
